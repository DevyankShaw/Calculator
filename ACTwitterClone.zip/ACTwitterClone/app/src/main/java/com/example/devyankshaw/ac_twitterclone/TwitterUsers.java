package com.example.devyankshaw.ac_twitterclone;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.shashank.sony.fancytoastlib.FancyToast;

import java.util.ArrayList;
import java.util.List;

public class TwitterUsers extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private ListView listView;
    private ArrayList<String> arrayList;
    private ArrayAdapter arrayAdapter;
    private int numberOfUsers;

    private String followedUser = "";//Stores the followed users of the current user and it is initialised to "" because if we don't initialise then it automatically puts null inside it
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twitter_users);


        listView = findViewById(R.id.listView);
        arrayList = new ArrayList();
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_checked, arrayList);//(context, row or  item list, data)
        listView.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        listView.setOnItemClickListener(this);

        FancyToast.makeText(this, "Welcome " + ParseUser.getCurrentUser().getUsername(), Toast.LENGTH_SHORT, FancyToast.INFO, true).show();

        final ProgressDialog dialog = new ProgressDialog(TwitterUsers.this);
        dialog.setMessage("Fetching Users....");
        dialog.show();
        try {//Here try block is used because if initially there is no user then parseQuery will not work and it may lead to app crash
            ParseQuery<ParseUser> parseQuery = ParseUser.getQuery();//query on the parseUsers

            parseQuery.whereNotEqualTo("username", ParseUser.getCurrentUser().getUsername());//Adding query not to accept the current username

            parseQuery.findInBackground(new FindCallback<ParseUser>() {//When querying over data is finished then done() will be notified and we can perform something
                @Override
                public void done(List<ParseUser> objects, ParseException e) {
                    if (e == null) {//There is no errors then if blocks executes
                        if (objects.size() > 0) {//There must be atleast one object of type ParseUser then if block executes

                            for (ParseUser user : objects) {//Iterating over each ParseUsers in the server

                                arrayList.add(user.getUsername());//This arrayList holds the username of the users except the current user
                            }

                            listView.setAdapter(arrayAdapter);/*By this the listView will know that we have an array adapter
                                                             and the listView will go ahead and update itself based
                                                             on the data that is sent from array adapter.*/
                            dialog.dismiss();

                            numberOfUsers = 0;
                            for (String twitterUser : arrayList){
                                if (ParseUser.getCurrentUser().getList("fanOf") != null) {//If the fanOf column list is initially null or have not followed anyone then our app may crash so in order to avoid this we put this if statement
                                    if (ParseUser.getCurrentUser().getList("fanOf").contains(twitterUser)) {
                                        numberOfUsers++;
                                        if((ParseUser.getCurrentUser().getList("fanOf").size()) == numberOfUsers) {
                                            // followedUser = followedUser + twitterUser + "," + " ";
                                            followedUser = followedUser + "& " + twitterUser;
                                        }else {
                                            //followedUser = followedUser + "& " + twitterUser;
                                            followedUser = followedUser + twitterUser + "," + " ";
                                        }
                                        listView.setItemChecked(arrayList.indexOf(twitterUser), true);
                                        FancyToast.makeText(TwitterUsers.this, ParseUser.getCurrentUser().getUsername() + " is following " + followedUser, Toast.LENGTH_LONG, FancyToast.INFO, true).show();

                                    }
                                }
                            }


                        }

                    }

                }
            });


        }catch (Exception e){
            FancyToast.makeText(this, "No Users", Toast.LENGTH_SHORT,FancyToast.INFO,false).show();
        }




    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //MenuInflater menuInflater = getMenuInflater();//inflating or adding menu to our Twitter Users Activity
        //menuInflater.inflate(R.menu.my_menu, menu);
        //or
        getMenuInflater().inflate(R.menu.my_menu, menu);//inflating or adding menu to our Twitter Users Activity

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.logoutUserItem){
            ParseUser.getCurrentUser().logOut();
            Intent intent = new Intent(TwitterUsers.this, LoginActivity.class);
            startActivity(intent);
            finish();//In order to not show the current Activity i.e TwitterUsers Activity after user has logged out
        }
        if(item.getItemId() == R.id.sendTweets){
            Intent intent = new Intent(TwitterUsers.this, SendTweetActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        CheckedTextView checkedTextView = (CheckedTextView) view;//Assign each view/item in the listView to this checkedTextView
        if (checkedTextView.isChecked()){
            FancyToast.makeText(TwitterUsers.this, arrayList.get(position) + " is now followed", Toast.LENGTH_SHORT,FancyToast.INFO,true).show();
            //Following
            ParseUser.getCurrentUser().add("fanOf", arrayList.get(position));//eg: arun is fanOf devyank
        }else {
            FancyToast.makeText(TwitterUsers.this, arrayList.get(position) + " is not followed", Toast.LENGTH_SHORT,FancyToast.INFO,true).show();
            //Unfollowing
            ParseUser.getCurrentUser().getList("fanOf").remove(arrayList.get(position));//As we are dealing with array or arrayList so we need to fetch the list of fans of the current user through getList() and then remove the fan from the fanOf column
            List currentUserFanOfList = ParseUser.getCurrentUser().getList("fanOf");
            ParseUser.getCurrentUser().remove("fanOf");
            ParseUser.getCurrentUser().add("fanOf", currentUserFanOfList);
        }

        ParseUser.getCurrentUser().saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if(e == null){
                    FancyToast.makeText(TwitterUsers.this, "Saved", Toast.LENGTH_SHORT, FancyToast.SUCCESS, true).show();
                }
            }
        });
    }
}
